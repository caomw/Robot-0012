function da=dAngle(a1,a2)
    da=atan2(sin(a1-a2), cos(a1-a2));
end