function R=Rot(alpha)
    R=[cos(alpha) -sin(alpha);
        sin(alpha) cos(alpha)];
end